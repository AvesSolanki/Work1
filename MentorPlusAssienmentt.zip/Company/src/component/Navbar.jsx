import React from "react";

const Navbar = () => {
  return (
    <div className="navar flex justify-between items-center sm:mb-5 py-2 bg-white shadow-lg
    sm:h-full sm:w-[30%] sm:flex-col sm:justify-start sm:bg-[#fafafa] sm:shadow-none ">
      <div className="left flex items-center mx-3 md:text-md ">
        <span className="flex w-4 h-4 bg-[#1d375c] rounded-[5px] mx-1 text-white text-xs justify-center items-center ">M</span>
        <span className="head text-[#1d375c] font-bold">
          Mentor<span className="text-[#e03259] font-bold">Plus</span>
        </span>
      </div>
      <div className="right flex flex-col space-y-1 mx-3 sm:hidden">
        <span className="bg-[#31486a] w-4 h-0.5 "></span>
        <span className="bg-[#31486a] w-4 h-0.5 "></span>
        <span className="bg-[#31486a] w-2 h-0.5 "></span>
      </div>
      <div className="right hidden sm:block space-y-2 my-3 md:my-4">
        <div className="spanNavItems bg-gradient-to-r from-[#b6d4ff] to-[#8ebcfd] px-8 border-2 border-gray-200 text-xs  font-medium rounded-md flex justify-center items-center py-2 md:px-10">Home</div>
        <div className="spanNavItems bg-[#e8f2ff] px-8 border-2 border-gray-200 text-xs  font-medium rounded-md flex justify-center items-center py-2 md:px-10">Profile</div>
        <div className="spanNavItems bg-[#e8f2ff] px-8 border-2 border-gray-200 text-xs  font-medium rounded-md flex justify-center items-center py-2 md:px-10 h-9"></div>
        <div className="spanNavItems bg-[#e8f2ff] px-8 border-2 border-gray-200 text-xs  font-medium rounded-md flex justify-center items-center py-2 md:px-10 h-9"></div>
        <div className="spanNavItems bg-[#e8f2ff] px-8 border-2 border-gray-200 text-xs  font-medium rounded-md flex justify-center items-center py-2 md:px-10 h-9"></div>
      </div>
    </div>
  );
};

export default Navbar;
