import React from "react";
import Navbar from "./Navbar";
import axios from "axios";
import { useEffect, useState } from "react";

const Home = () => {
  const [data, setData] = useState([]);
  const [updatetime, setUpdatetime] = useState([]);
  const [bg, setBg] = useState("");


  const getdata = async()=>{
   await axios.get("https://mentorplus.s3.ap-south-1.amazonaws.com/config/availability.json").then((res)=>{
      console.log(res.data);
      const info = res.data;
      setData(info);
      console.log(data);
    }).catch((err)=>{
      console.log("Internal Server Error ===> ",err)
    })
  }
  const update = (data,bg) =>{
    setUpdatetime(data)
    setBg(bg);
    console.log(updatetime)
  }

  const day = [
    "sun",
    "Mon",
    "Tue",
    "Wed",
    "Thu",
    "Fri",
    "Sat",
  ]

  useEffect(() => {
    getdata()
  },[1])
  
  


  return (

        // Start Main
    <div
      id="Mian"
      className="Maincontainer fixed h-[43rem] w-full bg-red-400 flex justify-center"
    >
        {/* /// Start content */}
      <div className="content border-[2px] bg-white border-gray-200 mt-12 flex flex-col w-[90%] h-[70%] sm:flex-row ">
        <Navbar />
        <div className="bottom mx-2 sm:w-[70%] my-5 sm:mt-10">
           <div className="icon hidden sm:block w-full border-t-[1px] border-gray-300 text-xs font-medium py-1">Back</div>
          <div className="Book font-bold text-md">
            <span className="relative py-1 ">
              Book
              <span className="rounded-l-md absolute flex bottom-0 w-[50%] h-[2px] bg-[#1d375c] left-0"></span>
              <span className="rounded-r-md  absolute bottom-0 w-[50%] h-[2px] bg-[#e03259] right-0"></span>
            </span>
            <span> Demo session Slot</span>
          </div>
          <div className="Date  my-3">
            <span className="font-bold text-sm">Select Date</span>
            <div className="scrollable overflow-y-scroll py-2 ml-2 my-1 flex flex-row space-x-1  sm:overflow-y-auto">
              {data.map((item) =>(
                 <div className="item flex flex-col justify-around items-center py-1.5 px-2 rounded-md w-12 text-xs font-medium border-2 border-[#1e4d8e]  hover:bg-[#1e4d8e]  hover:text-white sm:hover:bg-[#289125]" onClick={()=> update(item.available,"sm:bg-green ")}>
                 <span>{day[new Date(item.date).getDay()]}</span>
                 <span>{new Date(item.date).getDate()}</span>
                 <span>{new Date(item.date).toLocaleDateString('default',{month: 'short'})}</span>
               </div>
              ))}
            </div>
          </div>
          <div className="Slot ">
            <span className="font-bold text-sm">Select Date</span>
            <div className="SlotItems flex space-x-1">
             {updatetime.map((items) =>(
                <div className={`item flex flex-col justify-around items-center py-1 px-2 rounded-md w-[40%] text-xs font-bold border-2 border-[#1e4d8e]  hover:bg-[#1e4d8e]  hover:text-white sm:text-white sm:bg-[#289125]   my-2 ml-2 md:w-[30%] ${bg}`}>
                <span>{items.hour} PM - {items.min} PM</span>
              </div>
             ))}
            </div>
          </div>
          <div className="btn my-5">
            <button className="w-[50%] bg-[#021a3f] text-center text-sm font-medium text-white py-2 mx-3 rounded-md md:w-[30%]">
              Procced to Pay
            </button>
          </div>
        </div>
      </div>
              {/* /// End content */}

    </div>
         // End Main
  );
};

export default Home;
